package controller;

public class Test {
	public Test(){
		System.out.println("Hello World!!");
		
	}
}
