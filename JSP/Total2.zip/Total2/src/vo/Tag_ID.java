package vo;

public class Tag_ID {
	private String lecroom_id = null;
	private int width;
	private int height;
	private int tag_id;
	private int tag_id_old;
	public String getLecroom_id() {
		return lecroom_id;
	}
	public void setLecroom_id(String lecroom_id) {
		this.lecroom_id = lecroom_id;
	}
	public int getWidth() {
		return width;
	}
	public void setWidth(int width) {
		this.width = width;
	}
	public int getHeight() {
		return height;
	}
	public void setHeight(int height) {
		this.height = height;
	}
	public int getTag_id() {
		return tag_id;
	}
	public void setTag_id(int tag_id) {
		this.tag_id = tag_id;
	}
	public int getTag_id_old() {
		return tag_id_old;
	}
	public void setTag_id_old(int tag_id_old) {
		this.tag_id_old = tag_id_old;
	}
	
	
}
