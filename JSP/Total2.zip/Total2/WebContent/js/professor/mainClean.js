function mainClean(){
	$("#navigation_h1").html("");
	$("#main_article_h1").html("");
	$("#main_article_div1").html("");
	$("#main_article_div2").html("");
	$("#main_article_div3").html("");
	$("#main_article_div4").html("");
	$("#first_label").html("");
	$("#second_label").html("");
	$("#tab_item1_ul1").html("");
	$("#tab_item2_ul1").html("");
	//$("#").html("");
	//$("#").html("");
	//$("#").html("");
	//$("#").html("");
}